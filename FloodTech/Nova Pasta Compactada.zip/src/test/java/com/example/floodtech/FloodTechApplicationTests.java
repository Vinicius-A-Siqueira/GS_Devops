package com.example.floodtech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FloodTechApplicationTests {

    @Test
    void contextLoads() {
    }

}
